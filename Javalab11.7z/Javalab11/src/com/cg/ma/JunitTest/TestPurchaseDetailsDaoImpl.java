package com.cg.ma.JunitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.PurchaseDetailsException;

public class TestPurchaseDetailsDaoImpl {
	
	IMobileDao imobile;
	@Before
	public void setUp() throws Exception {
		
		imobile=new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		
		
	}

	@Test
	public void testInsertPurchaseDetails() {
		try{
			
			assertEquals(true,imobile.insertPurchaseDetails("Rithika", "rithikad@gmail.com", "9768130369",1001));
		}catch(PurchaseDetailsException e){
			
			e.printStackTrace();
		}

}
}
