/*package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;
import com.cg.ma.util.JdbcUtil;

public class PurchaseDetailsDaoImpl implements IPurchaseDetailsDao{
	
	Connection conn;
	PreparedStatement pst;
	PreparedStatement pst2;
	
	public boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mobileid) throws PurchaseDetailsException{
		
		try {
			conn=JdbcUtil.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int qty = 0;
		int rec=0;
		String iquery="INSERT INTO PurchaseDetails VALUES(purchase_seq.NEXTVAL,?,?,?,sysdate,?)";
		String squerry="SELECT quantity FROM mobiles WHERE mobileid=?";
		try {
			pst = conn.prepareStatement(squerry); //add try catch block
			pst.setInt(1,mobileid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				qty=rs.getInt(1);//to check qty>0 first take qty by get() then do insert
				System.out.println("Exsisting quantity:"+qty);
				
			}
			
			if(qty>0){
				
				pst=conn.prepareStatement(iquery);
				pst.setString(1, cust_name);
				pst.setString(2, cust_mail);
				pst.setString(3,cust_phone);
				pst.setInt(4, mobileid);
				
				PurchaseDetails pd = new PurchaseDetails();
				pd.setCname(cust_phone);
				pd.setMailid(cust_mail);
				pd.setPhoneno(cust_phone);
				pd.setMobileid(mobileid);
				
				rec=pst.executeUpdate();// insert query will be executed here
				if(rec>0){
					return true;
				}
				
			}
		}catch(SQLException e){
			
			e.printStackTrace();
			throw new PurchaseDetailsException("data not inserted");
		}
			
		return false;
	}

	public static void main(String[] args) throws PurchaseDetailsException {
		PurchaseDetailsDaoImpl p = new PurchaseDetailsDaoImpl();
		System.out.println(p.insertPurchaseDetails("gfhf", "gyg", "fytf", 1002));

	}

}
*/