package com.cg.onlineTicket.dto;

import java.sql.Date;

public class ShowDetail {
	private String showId;
	private String showName;
	private String location;
	private Date showDate;
	private int avlSeats;
	private float ticketPrice;
	

	public ShowDetail() {
		
	}


	public ShowDetail(String showId, String showName, String location,
			Date showDate, int avlSeats, float ticketPrice) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.showDate = showDate;
		this.avlSeats = avlSeats;
		this.ticketPrice = ticketPrice;
	}


	public String getShowId() {
		return showId;
	}


	public void setShowId(String showId) {
		this.showId = showId;
	}


	public String getShowName() {
		return showName;
	}


	public void setShowName(String showName) {
		this.showName = showName;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public Date getShowDate() {
		return showDate;
	}


	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}


	public int getAvlSeats() {
		return avlSeats;
	}


	public void setAvlSeats(int avlSeats) {
		this.avlSeats = avlSeats;
	}


	public float getTicketPrice() {
		return ticketPrice;
	}


	public void setTicketPrice(float ticketPrice) {
		this.ticketPrice = ticketPrice;
	}


	@Override
	public String toString() {
		return "ShowDetail [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avlSeats=" + avlSeats + ", ticketPrice=" + ticketPrice
				+ "]";
	}

	
	
}
