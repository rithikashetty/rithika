package com.cg.onlineTicket.service;

import java.util.List;

import com.cg.onlineTicket.dao.ITicketBookingDao;
import com.cg.onlineTicket.dao.TicketBookingDaoImpl;
import com.cg.onlineTicket.dto.ShowDetail;
import com.cg.onlineTicket.exceptions.OnlineBookingException;

public class TicketBookingServiceImpl implements ITicketBookingService {

	ITicketBookingDao bookingDao;
	
	public TicketBookingServiceImpl() {
		bookingDao= new TicketBookingDaoImpl();
	}

	@Override
	public List<ShowDetail> showAll() throws OnlineBookingException {
		
		return bookingDao.showAll();
	}

	@Override
	public ShowDetail getShow(String showId) throws OnlineBookingException {
		// TODO Auto-generated method stub
		return bookingDao.getShow(showId);
	}

	@Override
	public int updateSeats(String showName, int avlSeats, int bookSeats)
			throws OnlineBookingException {
		// TODO Auto-generated method stub
		return bookingDao.updateSeats(showName, avlSeats, bookSeats);
	}

}
