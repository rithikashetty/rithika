package com.cg.employeemanagement.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.service.EmployeeServiceImpl;
import com.cg.employeemanagement.service.IEmployeeService;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEmployeeService employeeService;

    public EmployeeController() {
      
    	 employeeService= new EmployeeServiceImpl();
    	
 
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		processRequest(request,response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		
		String path= request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/empl.do")){
		RequestDispatcher rs= request.getRequestDispatcher("addemployee.jsp");
		rs.forward(request,response);
		}
		
		if (path.equals("/empadd.do")){
			
			Employee emp = new Employee();
			
			String name= request.getParameter("jname");
			String qualificaton = request.getParameter("jequal");
			String salary=request.getParameter("jsal");
			
			emp.setEmpName(name);
			emp.setEmpQualification(qualificaton);
			emp.setEmpsalary(Double.parseDouble(salary));
			try {
				
			int empId=	employeeService.addEmployee(emp);
			
			//System.out.println(empId);
			request.setAttribute("id",empId);
			RequestDispatcher reqs =request.getRequestDispatcher("welcome.jsp");
			reqs.forward(request,response);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(path.equals("/showall.do")){
			
			List<Employee> myList = null;
			try {
				myList = employeeService.showAll();
				System.out.println(myList);//to see on console
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
			//System.out.println(myList);//checking purpose
			
			request.setAttribute("data", myList);
			RequestDispatcher req = request.getRequestDispatcher("showAll.jsp");
			req.forward(request, response);
			
		}else if(path.equals("/update.do")){
			
			String data=request.getQueryString();
			System.out.println(data);
			String empId=data.substring(3,7);
			System.out.println(empId);
			System.out.println("Update...........");
			int id=Integer.parseInt(empId);
			Employee eData = null;
			try {
				eData = employeeService.getEmployee(id);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			request.setAttribute("emp", eData);
			RequestDispatcher reqs =request.getRequestDispatcher("updatedata.jsp");
			reqs.forward(request,response);
			
			
			
		}else if(path.equals("/updateddata.do")){
			Employee emp1=new Employee();
			String newid1 = request.getParameter("newid");
			String newname1=request.getParameter("newname");
			String newqual1=request.getParameter("newqual");
			String newsal1=request.getParameter("newsal");
			
			emp1.setEmpid(Integer.parseInt(newid1));
			emp1.setEmpName(newname1);
			emp1.setEmpQualification(newqual1);
			emp1.setEmpsalary(Double.parseDouble(newsal1));
			
			
			boolean val=employeeService.updatedData(emp1);
			System.out.println(val);
			
			RequestDispatcher req = request.getRequestDispatcher("/showall.do");
			req.forward(request, response);
			
			
		}
		
		
	}
}
