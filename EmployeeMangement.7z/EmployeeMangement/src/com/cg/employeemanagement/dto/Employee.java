package com.cg.employeemanagement.dto;

public class Employee {
	
	private int empid;
	private String empName;
	private String empQualification;
	private double empsalary;
	public Employee(int empid, String empName, String empQualification,
			double empsalary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.empQualification = empQualification;
		this.empsalary = empsalary;
	}
	public Employee() {
		super();
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpQualification() {
		return empQualification;
	}
	public void setEmpQualification(String empQualification) {
		this.empQualification = empQualification;
	}
	public double getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName
				+ ", empQualification=" + empQualification + ", empsalary="
				+ empsalary + "]";
	}
	

}
