package com.cg.employeemanagement.service;

import java.util.List;

import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.IEmployeeDao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService{
IEmployeeDao empDao;
	

	public EmployeeServiceImpl() {
		empDao = new EmployeeDaoImpl();
		
	}
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		return empDao.addEmployee(emp);
		
	}

	@Override
	public List<Employee> showAll() throws EmployeeException  {
	
			return empDao.showAll();
	}
	@Override
	public Employee getEmployee(int id) throws EmployeeException {
		
		return empDao.getEmployee(id);
	}
	@Override
	public boolean updatedData(Employee emp1) {
		// TODO Auto-generated method stub
		return empDao.updatedData(emp1);
	}
};