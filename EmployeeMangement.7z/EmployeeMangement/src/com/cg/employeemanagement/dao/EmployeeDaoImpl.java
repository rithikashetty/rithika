package com.cg.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection conn=null;
		int msg=0;
		int empId=getEmployee();
		PreparedStatement pstm=null;
		String query = "INSERT INTO EMPLOYEEMANAGEMENT VALUES(?,?,?,?)";
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, empId);
			pstm.setString(2,emp.getEmpName());
			pstm.setString(3, emp.getEmpQualification());
			pstm.setDouble(4,emp.getEmpsalary());
			
			int status=pstm.executeUpdate();
			if (status==1){
				
				msg=empId;
				System.out.println(msg);
			}
			
		} catch (EmployeeException e) {
			throw new EmployeeException("problem occured");
			//e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("problem in INSERT");
		}
	finally{
		try{
			
			pstm.close();
			conn.close();
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();	
	}
	}
		return msg;
	}

	
	

	@Override
	public List<Employee> showAll() throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		List<Employee>myEmp=new ArrayList<Employee>();
		String query = "SELECT emp_id,emp_name,emp_qual,emp_sal FROM EMPLOYEEMANAGEMENT";
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(query);
			
	ResultSet rs = pstm.executeQuery();
				
	while(rs.next()){
		
		Employee e =new Employee();
		e.setEmpid(rs.getInt("emp_id"));
		e.setEmpName(rs.getString("emp_name"));
		e.setEmpQualification(rs.getString("emp_qual"));
		e.setEmpsalary(rs.getDouble("emp_sal"));
		myEmp.add(e);
	}
				
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in show");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	
		}
		}
		return myEmp;
	}

	public int getEmployee(){
		int empId=0;
		Connection conn=null;
		PreparedStatement pstm=null;
		String query = "SELECT empm_id_seq.NEXTVAL FROM DUAL";
			try {
				conn=DbUtil.obtainconnection();
				pstm=conn.prepareStatement(query);
				
		ResultSet rs = pstm.executeQuery();
				
				while(rs.next()){
					empId=rs.getInt(1);
					
				}
				
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		return empId;
		
	}

	public Employee getEmployee(int id) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		Employee e =new Employee();
		String query= "SELECT emp_id,emp_name,emp_qual,emp_sal from EMPLOYEEMANAGEMENT WHERE emp_id=?";
		
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, id);
	ResultSet rs = pstm.executeQuery();
				
	while(rs.next()){
		
		//retriving values from database and setting in dto
		e.setEmpid(rs.getInt("emp_id"));
		e.setEmpName(rs.getString("emp_name"));
		e.setEmpQualification(rs.getString("emp_qual"));
		e.setEmpsalary(rs.getDouble("emp_sal"));
		//myEmp.add(e);
	}
				
			
		} catch (EmployeeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new EmployeeException("Problem in show");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();	
		}
		}
		return e;
	
	}




	@Override
	public boolean updatedData(Employee emp1) {
		Connection conn=null;
		PreparedStatement pstm=null;
		int status=0;
		String uquery="UPDATE EMPLOYEEMANAGEMENT SET emp_name=?,emp_qual=?,emp_sal=? WHERE emp_id=?  ";
		
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(uquery);
			pstm.setString(1, emp1.getEmpName());
			pstm.setString(2, emp1.getEmpQualification());
			pstm.setDouble(3, emp1.getEmpsalary());
			pstm.setInt(4, emp1.getEmpid());
			status=pstm.executeUpdate();
			
			if(status>0){
				
				System.out.println("data is updated successfully");
				return true;
			}
			else{
			
				System.out.println("data is not updated");
				
			}
			
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
}
