SELECT * FROM Consumers;

SELECT * FROM BillDetails;