package com.cg.bill.service;

import java.util.List;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.bean.Consumers;
import com.cg.bill.dao.EBillDaoImpl;
import com.cg.bill.dao.IEBillDao;
import com.cg.bill.exceptions.BillException;

public class EBillServiceImpl implements IEBillService {

	IEBillDao billDao;
	public EBillServiceImpl() {
		billDao= new EBillDaoImpl();
	}

	@Override
	public List<Consumers> showAll() throws BillException {
		
		return billDao.showAll();
	}

	@Override
	public Consumers searchCons(int id) throws BillException {
		// TODO Auto-generated method stub
		return billDao.searchCons(id);
	}

	@Override
	public List<BillDetails> getBill(int conId) throws BillException {
		
		return billDao.getBill(conId);
	}

	@Override
	public int addBillDetail(int cons_num, BillDetails billDetail) throws BillException {
		
		return billDao.addBillDetail(cons_num, billDetail);
	}
}
