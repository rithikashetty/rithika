package com.cg.bill.controller;

import java.io.IOException;



import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bill.bean.BillDetails;
import com.cg.bill.bean.Consumers;
import com.cg.bill.exceptions.BillException;
import com.cg.bill.service.EBillServiceImpl;
import com.cg.bill.service.IEBillService;


@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       IEBillService billService;
       private RequestDispatcher dispatch;
       private String nextJsp;
    
    public EBillController() {
        super();
        billService= new EBillServiceImpl();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path= request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/login.do")){
			String userNm= request.getParameter("uname");
			String userPass= request.getParameter("pswd");
			
			if((userNm.equals("admin")) && (userPass.equals("admin"))) {
				System.out.println("Login successful");
				nextJsp="/index.jsp";
			}
			
			else{
				System.out.println("Login Unsuccessful");
				//response.sendRedirect("failure.html");
				request.setAttribute("loginEr", "Invalid credentials.. try again");
				nextJsp="/home.jsp";
			}
			
		}
		
		else if(path.equals("/showConsumerList.do")){
			List<Consumers> myList= null;
			try {
				 myList= billService.showAll();
				 request.setAttribute("data", myList);
				nextJsp= "/showConsumerList.jsp";
					
			} catch (BillException e) {
				// TODO Auto-generated catch block
				request.setAttribute("errMsg", "Error while retrieving details");
				nextJsp="/errors.jsp";
				e.printStackTrace();
			}
			
		}
		
		
		else if(path.equals("/searchConsumer.do")){
			nextJsp= "/searchConsumer.jsp";
			
		}
		
		
		else if(path.equals("/search.do")){
			String consIdStr= request.getParameter("cId");
			int consId= Integer.parseInt(consIdStr);
			
			try {
				Consumers consumer= billService.searchCons(consId);
				 request.setAttribute("dataCons", consumer);
					nextJsp= "/showConsumer.jsp";
				
			} catch (BillException e) {
				// TODO Auto-generated catch block
				request.setAttribute("errMsg", "Error while searching consumer");
				nextJsp="/errors.jsp";
				e.printStackTrace();
			}
			
			
			//nextJsp= "/searchConsumer.jsp";
			
		}
		
		else if(path.equals("/showBill.do")){
			
			System.out.println("Called showBill for 1");
			List<BillDetails> billData= null;
			String data= request.getQueryString();
					String u_id= data.substring(3);
					
					int uid= Integer.parseInt(u_id);
					System.out.println("For id:"+uid);
					try {
						billData= billService.getBill(uid);
						request.setAttribute("Cid", uid);
						 request.setAttribute("billData", billData);
							nextJsp= "/showBills.jsp";
							
					} catch (BillException e) {
						// TODO Auto-generated catch block
						request.setAttribute("errMsg", "Error while getting bill details");
						nextJsp="/errors.jsp";
						e.printStackTrace();
					}
					
					
					
		}
		
		else if(path.equals("/generate.do")){
			String data= request.getQueryString();
			String u_id= data.substring(3);
			
			int uid= Integer.parseInt(u_id);
			System.out.println("Called generate For id:"+uid);
			request.setAttribute("Cid", uid);
			nextJsp= "/getData.jsp";
			
		}
		
		else if(path.equals("/calculate.do")){
			String conNum= request.getParameter("con_num");
			String lRead= request.getParameter("lReading");
			String cRead= request.getParameter("cReading");
			
			int consNum= Integer.parseInt(conNum);
			int lsRead=Integer.parseInt(lRead);
			int crRead=Integer.parseInt(cRead);
			if(crRead<lsRead){
				System.out.println("Currnet reading cannot be less than last reading.");
				request.setAttribute("Setmsg", "Currnet reading cannot be less than last reading.");
				nextJsp= "/getData.jsp";
				//RequestDispatcher disp= request.getRequestDispatcher("getData.JSP");
				//disp.forward(request, response);
			}
			
			int unitCon;
			float netAmt;
			int fix=100;
			
			unitCon= crRead-lsRead;
			netAmt= (float) ((unitCon*1.15)+fix);
			
			java.util.Date d= new java.util.Date();
			long current= d.getTime();
			Date dt= new Date(current);
			
			BillDetails billDet= new BillDetails();
			billDet.setConsumerNum(consNum);
			billDet.setCurntReading(crRead);
			billDet.setUnitConsumed(unitCon);
			billDet.setNetAmnt(netAmt);
			billDet.setBillDate(dt);
			
			try {
				int billId= billService.addBillDetail(consNum, billDet);
				billDet.setBillNum(billId);
				System.out.println("Bill ID GENERATED: "+billId);
				
				request.setAttribute("BillData", billDet);
				nextJsp= "/billSuccess.jsp";
				
				//RequestDispatcher disp= request.getRequestDispatcher("billSuccess.jsp");
				//disp.forward(request, response);
				
			
			} catch (BillException e) {
				// TODO Auto-generated catch block
				request.setAttribute("errMsg", "Error while generating bill");
				nextJsp="/errors.jsp";
				e.printStackTrace();
			}
			
		}
		dispatch= request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
	}
}
