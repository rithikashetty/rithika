package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.util.DbUtil;

public class EBillDaoImpl implements IEBillDao {

	@Override
	public User getUserDetails(String userName) throws BillException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String qry = "SELECT PASSWORD from USERMASTER where USERNAME=?";
		try {

			conn = DbUtil.obtainconnection();
			pstm = conn.prepareStatement(qry);
			pstm.setString(1, userName);
			rs = pstm.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				;
				User user = new User(userName, password);
				return user;
			} else {

				throw new BillException("Wrong username");
			}
		} catch (SQLException e) {

			throw new BillException("JDBC Failed", e);
		} finally {
			try {

				pstm.close();
				conn.close();

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	@Override
	public List<Consumer> showAll() throws BillException {
		Connection conn = null;
		PreparedStatement pstm = null;
		List<Consumer> myList = new ArrayList<Consumer>();
		String selectcquery = "SELECT consumer_num, consumer_name,address FROM Consumers";

		try {
			conn = DbUtil.obtainconnection();
			pstm = conn.prepareStatement(selectcquery);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {

				Consumer c = new Consumer();
				c.setConsumerNo(rs.getInt("consumer_num"));
				c.setConsumername(rs.getString("consumer_name"));
				c.setAddress(rs.getString("address"));
				myList.add(c);

			}

		}/*
		 * catch(BillException e){
		 * 
		 * e.printStackTrace(); throw new
		 * BillException("Problem occured while showing consumer details");//add
		 * throw billexception near method name
		 * 
		 * }
		 */catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			try {

				pstm.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return myList;
	}

	@Override
	public Consumer searchConsumer(int consumerno1) throws BillException {

		Connection conn = null;
		PreparedStatement pstm = null;
		conn = DbUtil.obtainconnection();

/*		String cnocheck = "SELECT consumer_num from consumers where consumer_num=?";
		boolean flag = false;
		int cno=0;

		try {
			ResultSet rs1 = null;
			pstm = conn.prepareStatement("cnocheck");
			pstm.setInt(1, consumerno1);
			rs1 = pstm.executeQuery();

			
			 * while (rs1.next()) {
			 * 
			 * int conNum = rs1.getInt(1); System.out.println(conNum); if
			 * (conNum == consumerno) {
			 * 
			 * flag = true; System.out.println(flag); break;
			 * 
			 * }
			 * 
			 * }
			 
			while(rs1.next()) {
				cno=rs1.getInt(1);
				 flag = true;
				System.out.println(flag);
			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("Problem occured while entering consumer no");
		}

		if (flag == true) {*/

			Consumer consumer = new Consumer();
			String searchquery = "SELECT consumer_num, consumer_name,address from consumers where consumer_num=?";

			try {
				ResultSet rs = null;
				conn = DbUtil.obtainconnection();
				pstm = conn.prepareStatement(searchquery);
				pstm.setInt(1, consumerno1);
				rs = pstm.executeQuery();

				while (rs.next()) {

					consumer.setConsumerNo(rs.getInt("consumer_num"));
					consumer.setConsumername(rs.getString("consumer_name"));
					consumer.setAddress(rs.getString("address"));
				}

				System.out.println(consumer);
				return consumer;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("error search");
				e.printStackTrace();
				throw new BillException("search error");
			}
	/*	} else {

			throw new BillException("Consumer no doesnot exist");
		}*/
		// return consumer;

	}

	@Override
	public List<BillDetails> getConsumerNo(int cno) throws BillException {
		Connection conn=null;
		PreparedStatement pstm=null;
		BillDetails bd = new BillDetails();
		List<BillDetails> bill=new ArrayList<BillDetails>();
		String selectquery="SELECT bill_num,consumer_num, cur_reading,unitConsumed, netAmount, bill_date FROM BillDetails WHERE consumer_num=?";
		
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(selectquery);
			pstm.setInt(1, cno);
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next()){
				
				bd.setBillno(rs.getInt("bill_num"));
				bd.setConsumerno(rs.getInt("consumer_num"));
				bd.setCrntreading(rs.getInt("cur_reading"));
				bd.setUnitconsumed(rs.getInt("unitConsumed"));
				bd.setNetamount(rs.getInt("netAmount"));
				bd.setDate(rs.getDate("bill_date"));
				System.out.println("In Dao"+bd);
				bill.add(bd);
			}
			
		} /*catch (BillException e) {
			
			throw new BillException("Problem in Show",e);
		}*/catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BillException("Problem in Show",e);
		}
		
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();	
		}
		}
		return bill;
	}

	@Override
	public int addBillDetail(int consumerno, BillDetails billDetail)
			throws BillException {
		

		int msg = 0;
		Connection conn = null;
		conn = DbUtil.obtainconnection();
		PreparedStatement stmtcheck = null;
		String checkQuery = "SELECT consumer_num from consumers ";
		boolean flag = false;
		try {
			stmtcheck = conn.prepareStatement(checkQuery);// select is executed
															// here
			ResultSet res2 = stmtcheck.executeQuery();
			while (res2.next()) {

				int conNum = res2.getInt(1);
				System.out.println(conNum);
				if (conNum == consumerno) {

					flag = true;
					System.out.println(flag);
					break;

				}

			}
		} catch (SQLException e) {
			throw new BillException("problem ocured while validating consumer no");
			//e.printStackTrace();
		}

		if (flag == true) {
			conn = DbUtil.obtainconnection();
			PreparedStatement pstm = null; 

			int billNum = getBillNum();

			String insertquery = "INSERT INTO BillDetails VALUES(?,?,?,?,?,?)";
			try {

				pstm = conn.prepareStatement(insertquery);
				pstm.setInt(1, billNum);
				pstm.setInt(2, consumerno);
				pstm.setFloat(3, billDetail.getCrntreading());
				pstm.setFloat(4, billDetail.getUnitconsumed());
				pstm.setFloat(5, billDetail.getNetamount());
				pstm.setDate(6, billDetail.getDate());
				int status = pstm.executeUpdate();
				if (status == 1) {

					msg = billNum;
					System.out.println("billNum:" + msg);
				}
				return msg;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BillException("problem in INSERT");
			} finally {
				try {

					pstm.close();
					conn.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		//return msg;
		
		else {
			
			throw new BillException("Consumer no doesnot exist");
		}
	}
	
	public int getBillNum() {
		Connection conn = null;
		int billId = 0;
		PreparedStatement pstm = null;
		String qry = "SELECT seq_bill_num.NEXTVAL FROM dual";
		try {

			conn = DbUtil.obtainconnection();
			pstm = conn.prepareStatement(qry);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				billId = rs.getInt(1);
				System.out.println(billId);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return billId;
	}

}
