package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.dao.EBillDaoImpl;
import com.cg.ebill.dao.IEBillDao;
import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;



public class EBillServiceImpl implements IEbillService {

	private IEBillDao billdao;
	public EBillServiceImpl() {
		billdao = new EBillDaoImpl();
	}

	@Override
	public User getUserDetails(String userName) throws BillException {
		
		return billdao.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String username, String password) throws BillException {

		
		User user =billdao.getUserDetails(username);
		if(password.equals(user.getPassword()))
		{
			return true;
		}
		else
		{
		return false;
	
		}
		
	}

	@Override
	public List<Consumer> showAll() throws BillException {//throws BillException
		// TODO Auto-generated method stub
		return billdao.showAll();
	}

	@Override
	public Consumer searchConsumer(int consumerno1) throws BillException {
		// TODO Auto-generated method stub
		return billdao.searchConsumer(consumerno1);
	}

	@Override
	public List<BillDetails> getConsumerNo(int cno) throws BillException {
		// TODO Auto-generated method stub
		return billdao.getConsumerNo(cno);
	}

	@Override
	public int addBillDetail(int consumerno, BillDetails billDetail)
			throws BillException {
		// TODO Auto-generated method stub
		return billdao.addBillDetail(consumerno,billDetail);
	}

}
