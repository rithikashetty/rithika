package com.cg.ebill.controller;

import java.io.IOException;





import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.service.EBillServiceImpl;
import com.cg.ebill.service.IEbillService;





@WebServlet("*.do")///eBillController
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEbillService eBillServices;

    public EBillController() {
    	eBillServices=new EBillServiceImpl();
    
    }

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		String path= request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/log.do")){
			
			RequestDispatcher rs=request.getRequestDispatcher("login.jsp");
			rs.forward(request, response);
		}
if(path.equals("/login.do")){
			
			String uName=request.getParameter("username");
			String passwrd=request.getParameter("password");
		try{	
			boolean isAuthenticated=eBillServices.isUserAuthenticated(uName, passwrd);
			if(isAuthenticated){
				System.out.println("index1");
				RequestDispatcher reqs =request.getRequestDispatcher("index1.html");
				reqs.forward(request,response);
			}
			else{
				
				RequestDispatcher reqs =request.getRequestDispatcher("loginfailed.jsp");
				reqs.forward(request,response);
				
			}
		}catch(Exception e){
			
			RequestDispatcher reqs =request.getRequestDispatcher("loginfailed.jsp");
			reqs.forward(request,response);
			
			}
		}if(path.equals("/consumerlist.do")){
			
		     List<Consumer> myList = null;
		     
		     try {
				myList=eBillServices.showAll();
				System.out.println(myList);
				
			} catch (BillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Problem occured while showing customer details");
			}
		     request.setAttribute("data", myList);
				RequestDispatcher req = request.getRequestDispatcher("show_consumerList.jsp");
				req.forward(request, response);
			
			
		}if(path.equals("/searchconsumer.do")){
			
			String consumeno = request.getParameter("cno");
			int consumerno1=Integer.parseInt(consumeno);
			
			try {
				Consumer consumer=eBillServices.searchConsumer(consumerno1);//surround with try catch
				System.out.println(consumer);
				
				request.setAttribute("consumersearch", consumer);
				RequestDispatcher req = request.getRequestDispatcher("show_consumer.jsp");
				req.forward(request, response);
				
			} catch (BillException e) {
				String msg="error while searching consumer details from consumer no";
				e.printStackTrace();
				System.out.println("problem occured in searching consumerdetails from consumere number");
				request.setAttribute("searcherrormsg", msg);
				RequestDispatcher req = request.getRequestDispatcher("error.jsp");
				req.forward(request, response);
			}
		

		}if(path.equals("/searchshowbill.do")){
			System.out.println("searchshowbill is called");
			String data=request.getQueryString();
			System.out.println(data);
			
			String conno=data.substring(3,9);
			System.out.println(conno);
			int cno=Integer.parseInt(conno);
			
			
			try {
				List<BillDetails> bill =eBillServices.getConsumerNo(cno);
				System.out.println("In con"+bill);
				request.setAttribute("cno1", cno);
				request.setAttribute("consumeno",bill);
				RequestDispatcher reqs =request.getRequestDispatcher("show_bills.jsp");
				reqs.forward(request,response);
			} catch (BillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}if(path.equals("/nextbill.do")){
			

			RequestDispatcher rs=request.getRequestDispatcher("user_info.jsp");
			rs.forward(request, response);
		}
		if(path.equals("/calculatebill.do")){
			
			String consumeno = request.getParameter("cnos");//retrive from jsp
			String lstread = request.getParameter("lread");
			String crntread = request.getParameter("cread");
			
			int consumerno=Integer.parseInt(consumeno);
			int lstmtrread = Integer.parseInt(lstread);
			int crntmnthread = Integer.parseInt(crntread);
			
			if(crntmnthread < lstmtrread){
				System.out.println("Current Month meter reading cannot be less than Last Month meter reading");
				request.setAttribute("msg","Current Month meter reading cannot be less than Last Month meter reading");
				RequestDispatcher reqs =request.getRequestDispatcher("user_info.jsp");
				reqs.forward(request,response);
			}else{
				
				int unitconsumed;
				int netamount;
				int fixedcharge=100;
				unitconsumed=crntmnthread-lstmtrread;
				System.out.println("unitconsumed:"+unitconsumed);
				netamount=(int) (unitconsumed *1.5+fixedcharge);
				System.out.println("net Amount:"+netamount);
				
				java.util.Date d= new java.util.Date();
				long current = d.getTime();
				Date dt = new Date(current);
				
				BillDetails billDetail = new BillDetails();
				
				billDetail.setConsumerno(consumerno);//if not written then consumer no will print 0 in success.jsp
				billDetail.setCrntreading(crntmnthread);
				billDetail.setUnitconsumed(unitconsumed);
				billDetail.setNetamount(netamount);
				billDetail.setDate(dt);
				
				try {
					int billid=eBillServices.addBillDetail(consumerno,billDetail);
					System.out.println(billid);
					request.setAttribute("billdata",billDetail);
					RequestDispatcher reqs =request.getRequestDispatcher("bill_info.jsp");
					reqs.forward(request,response);
				} catch (BillException e) {
					e.printStackTrace();
					System.out.println("Problem occured at calculate.do");
					//response.sendRedirect("invalid.jsp");//you cant pass any msg
					String cnoerror="Consumer no does not exsit";
					request.setAttribute("consumernoerror", cnoerror);
					RequestDispatcher reqs =request.getRequestDispatcher("mainMenu.jsp");
					reqs.forward(request,response);
				}
				

			}
			
			
		}
		
	}
}
