Select * from USERMASTER;
SELECT bill_num,consumer_num, cur_reading,unitConsumed, netAmount, bill_date FROM BillDetails WHERE consumer_num=100002;
