package com.cg.ticketbooking.util;



import java.sql.Connection;


import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.ticketbooking.exception.TicketBookException;



public class DbUtil {

	
	public static Connection obtainconnection() throws TicketBookException{ 
		Connection conn=null;
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource source =(DataSource)context.lookup("java:/OracleDS");
			conn=source.getConnection();
		} catch (NamingException e) {
			
			e.printStackTrace();
			throw new TicketBookException("Problem in connection");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		return conn;
	}
}
