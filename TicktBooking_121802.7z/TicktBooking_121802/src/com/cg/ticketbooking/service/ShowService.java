package com.cg.ticketbooking.service;

import java.util.List;

import com.cg.ticketbooking.dto.Show;
import com.cg.ticketbooking.exception.TicketBookException;

public interface ShowService {

	public List<Show>showAll()throws TicketBookException;

	public Show getShowId(String id) throws TicketBookException;

	public boolean updateSeat(Show show1);
}
