package com.cg.ticketbooking.exception;

public class TicketBookException extends Exception {

	public TicketBookException() {
		// TODO Auto-generated constructor stub
	}

	public TicketBookException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TicketBookException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TicketBookException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TicketBookException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
