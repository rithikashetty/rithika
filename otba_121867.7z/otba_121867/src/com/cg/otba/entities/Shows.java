package com.cg.otba.entities;

import java.io.Serializable;
import java.util.Date;

public class Shows implements Serializable{

	private static final long serialVersionUID = 1L;
	private String showid;
	private String showname;
	private String location;
	private Date showdate;
	private int avseats;
	private double pricetickets;
	
	
	public Shows() {
		super();
	}

	public String getShowid() {
		return showid;
	}

	public Shows(String showid, String showname, String location,
			Date showdate, int avseats, double pricetickets) {
		super();
		this.showid = showid;
		this.showname = showname;
		this.location = location;
		this.showdate = showdate;
		this.avseats = avseats;
		this.pricetickets = pricetickets;
	}

	public void setShowid(String showid) {
		this.showid = showid;
	}

	public String getShowname() {
		return showname;
	}

	public void setShowname(String showname) {
		this.showname = showname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

	public int getAvseats() {
		return avseats;
	}

	public void setAvseats(int avseats) {
		this.avseats = avseats;
	}

	public double getPricetickets() {
		return pricetickets;
	}

	public void setPricetickets(double pricetickets) {
		this.pricetickets = pricetickets;
	}

	@Override
	public String toString() {
		return "Shows [showid=" + showid + ", showname=" + showname
				+ ", location=" + location + ", showdate=" + showdate
				+ ", avseats=" + avseats + ", pricetickets=" + pricetickets
				+ "]";
	}

	
	
	
	
}
