package com.cg.otba.services;

import java.util.List;

import com.cg.otba.Daos.ITicketBookingDao;
import com.cg.otba.Daos.TicketBookingImpl;
import com.cg.otba.entities.Shows;
import com.cg.otba.exceptions.BookingException;

public class TicketBookingServiceImpl implements ITicketBookingService{
	ITicketBookingDao showDao;
	public TicketBookingServiceImpl()  {
		showDao = new TicketBookingImpl();
	}
	
	@Override
	public List<Shows> ShowAll() throws BookingException {
		return showDao.ShowAll();
	}

	@Override
	public Shows getShowDetails(String showid) throws BookingException {
		return showDao.getShowDetails(showid);
	}

	@Override
	public boolean updateData(Shows show, int seat) throws BookingException {
		return showDao.updateData(show, seat);
	}

	
}
