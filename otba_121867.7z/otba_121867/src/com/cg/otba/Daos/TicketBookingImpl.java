package com.cg.otba.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.otba.entities.Shows;
import com.cg.otba.exceptions.BookingException;

public class TicketBookingImpl implements ITicketBookingDao {

	@Override
	public List<Shows> ShowAll() throws BookingException {
		// to display all the details of shows
		Connection conn = null;
		PreparedStatement pstm = null;
		List<Shows> slist = new ArrayList<Shows>();
		String query = "SELECT SHOWID, SHOWNAME, LOCATION, SHOWDATE,PRICETICKET, AVSEATS FROM SHOWDETAILS";
		try {
			conn = com.cg.otba.util.DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				Shows s = new Shows();
				s.setShowid(res.getString("SHOWID"));
				s.setShowname(res.getString("SHOWNAME"));
				s.setLocation(res.getString("LOCATION"));
				s.setShowdate(res.getDate("SHOWDATE"));
				s.setPricetickets(res.getDouble("PRICETICKET"));
				s.setAvseats(res.getInt("AVSEATS"));

				slist.add(s);
			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("Problem in show");
		}finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return slist;
	}

	@Override
	public Shows getShowDetails(String showid) throws BookingException {
		//get the show details for particular show
		Connection conn = null;
		PreparedStatement pstm = null;
		Shows s = new Shows();
		String query = "SELECT SHOWNAME,PRICETICKET, AVSEATS FROM SHOWDETAILS WHERE SHOWID=?";

		try {
			conn = com.cg.otba.util.DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, showid);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {

				s.setShowname(res.getString("SHOWNAME"));
				s.setPricetickets(res.getDouble("PRICETICKET"));
				s.setAvseats(res.getInt("AVSEATS"));

			}
		} catch (BookingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("Problem in show");
		}
		finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return s;
	}

	@Override
	public boolean updateData(Shows show, int seat) throws BookingException {
		//book the ticket and update in show details table
		Connection conn = null;
		PreparedStatement pstm = null;
		String query = "UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWNAME=?";
		try {
			conn = com.cg.otba.util.DBUtil.obtainConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, seat);
			pstm.setString(2, show.getShowname());
			int rec = pstm.executeUpdate();
			if (rec > 0) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BookingException("Problem in booking ticket");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;

	}
}
