package com.cg.otba.Daos;

import java.util.List;

import com.cg.otba.entities.Shows;
import com.cg.otba.exceptions.BookingException;


public interface ITicketBookingDao {
	public List<Shows> ShowAll() throws BookingException ;
	public Shows getShowDetails(String showid) throws BookingException;
	public boolean updateData(Shows show, int seat)throws BookingException;
}
