package com.capgemini.appl.dao;

import com.capgemini.appl.entities.User;

import com.capgemini.appl.exception.UserException;

public interface UserMasterDao {
	
	User getUserDetails(String userName)throws UserException;

}
