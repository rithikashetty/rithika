package com.capgemini.appl.services;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;

public interface UserMasterService {
	User getUserDetails(String userName)throws UserException;
	boolean isUserAuthenticated(String userName,String password) throws UserException;
}
