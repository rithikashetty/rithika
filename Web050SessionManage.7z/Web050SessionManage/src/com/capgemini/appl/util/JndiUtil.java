package com.capgemini.appl.util;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.appl.exception.UserException;
public class JndiUtil {

	private DataSource dataSource;
	public JndiUtil() throws UserException {
	
		try {
			Context ctx = new InitialContext(); // Get refrence to renote jndi//reached to wildfly and bought jndi
			dataSource=(DataSource)ctx.lookup("java:/OracleDS");//proxy dataSource
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UserException("Failed to get JNDI Context",e);
		}
	}

	
	public Connection getConnection() throws SQLException{//import connection from java.sql
		
		return dataSource.getConnection();//connections are already established.no opening and closing connection.threadsafe connection
	}

}
