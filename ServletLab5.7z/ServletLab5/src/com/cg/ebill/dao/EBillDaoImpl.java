package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.util.DbUtil;

public class EBillDaoImpl implements IEBillDao {

	@Override
	public User getUserDetails(String userName) throws BillException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String qry = "SELECT PASSWORD from USERMASTER where USERNAME=?";
		try {

			conn = DbUtil.obtainconnection();
			pstm = conn.prepareStatement(qry);
			pstm.setString(1, userName);
			rs = pstm.executeQuery();

			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				;
				User user = new User(userName, password);
				return user;
			} else {

				throw new BillException("Wrong username");
			}
		} catch (SQLException e) {

			throw new BillException("JDBC Failed", e);
		} finally {
			try {

				pstm.close();
				conn.close();

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	@Override
	public int addBillDetail(int consumerno, BillDetails billDetail)
			throws BillException {

		int msg = 0;
		Connection conn = null;
		conn = DbUtil.obtainconnection();
		PreparedStatement stmtcheck = null;
		String checkQuery = "SELECT consumer_num from consumers ";
		boolean flag = false;
		try {
			stmtcheck = conn.prepareStatement(checkQuery);// select is executed
															// here
			ResultSet res2 = stmtcheck.executeQuery();
			while (res2.next()) {

				int conNum = res2.getInt(1);
				System.out.println(conNum);
				if (conNum == consumerno) {

					flag = true;
					System.out.println(flag);
					break;

				}

			}
		} catch (SQLException e) {
			throw new BillException("problem ocured while validating consumer no");
			//e.printStackTrace();
		}

		if (flag == true) {
			conn = DbUtil.obtainconnection();
			PreparedStatement pstm = null;

			int billNum = getBillNum();

			String insertquery = "INSERT INTO BillDetails VALUES(?,?,?,?,?,?)";
			try {

				pstm = conn.prepareStatement(insertquery);
				pstm.setInt(1, billNum);
				pstm.setInt(2, consumerno);
				pstm.setFloat(3, billDetail.getCrntmnthread());
				pstm.setFloat(4, billDetail.getUnitconsumed());
				pstm.setFloat(5, billDetail.getNetamount());
				pstm.setDate(6, billDetail.getDt());
				int status = pstm.executeUpdate();
				if (status == 1) {

					msg = billNum;
					System.out.println("billNum:" + msg);
				}
				return msg;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BillException("problem in INSERT");
			} finally {
				try {

					pstm.close();
					conn.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		//return msg;
		
		else {
			
			throw new BillException("Consumer no doesnot exist");
		}

	}

	public int getBillNum() {
		Connection conn = null;
		int billId = 0;
		PreparedStatement pstm = null;
		String qry = "SELECT seq_bill_num.NEXTVAL FROM dual";
		try {

			conn = DbUtil.obtainconnection();
			pstm = conn.prepareStatement(qry);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				billId = rs.getInt(1);
				System.out.println(billId);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return billId;
	}
}
