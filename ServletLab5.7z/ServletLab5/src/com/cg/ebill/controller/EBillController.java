package com.cg.ebill.controller;

import java.io.IOException;

import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.services.EBillServiceImpl;
import com.cg.ebill.services.IEbillService;

@WebServlet("*.do")///eBillController
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    IEbillService eBillServices;   

    public EBillController() {
    	eBillServices=new EBillServiceImpl();
        
    }


	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		String path= request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/log.do")){
			
			RequestDispatcher rs=request.getRequestDispatcher("login.jsp");
			rs.forward(request, response);
		}
		if(path.equals("/login.do")){
			
			String uName=request.getParameter("username");
			String passwrd=request.getParameter("password");
		try{	
			boolean isAuthenticated=eBillServices.isUserAuthenticated(uName, passwrd);
			if(isAuthenticated){
				System.out.println("mainmenu");
				RequestDispatcher reqs =request.getRequestDispatcher("mainMenu.jsp");
				reqs.forward(request,response);
			}
			else{
				
				RequestDispatcher reqs =request.getRequestDispatcher("loginfailed.jsp");
				reqs.forward(request,response);
				
			}
		}catch(Exception e){
			
			RequestDispatcher reqs =request.getRequestDispatcher("loginfailed.jsp");
			reqs.forward(request,response);
			
			}
		}if(path.equals("/consumerdetail.do")){
			
			String consumeno = request.getParameter("cno");//retrive from jsp
			String lstread = request.getParameter("lread");
			String crntread = request.getParameter("cread");
			
			int consumerno=Integer.parseInt(consumeno);
			float lstmtrread = Float.parseFloat(lstread);
			float crntmnthread = Float.parseFloat(crntread);
			
			if(crntmnthread < lstmtrread){
				System.out.println("Current Month meter reading cannot be less than Last Month meter reading");
				request.setAttribute("msg","Current Month meter reading cannot be less than Last Month meter reading");
				RequestDispatcher reqs =request.getRequestDispatcher("mainMenu.jsp");
				reqs.forward(request,response);
			}else{
				
				float unitconsumed;
				float netamount;
				int fixedcharge=100;
				unitconsumed=crntmnthread-lstmtrread;
				System.out.println("unitconsumed:"+unitconsumed);
				netamount=(float) (unitconsumed *1.5+fixedcharge);
				
				System.out.println("net Amount:"+netamount);
				
				java.util.Date d= new java.util.Date();
				long current = d.getTime();
				Date dt = new Date(current);
				
				BillDetails billDetail = new BillDetails();
				
				billDetail.setConsumerNo(consumerno);//if not written then consumer no will print 0 in success.jsp
				billDetail.setCrntmnthread(crntmnthread);
				billDetail.setUnitconsumed(unitconsumed);
				billDetail.setNetamount(netamount);
				billDetail.setDt(dt);
			
				try {
					int billid = eBillServices.addBillDetail(consumerno,billDetail);
					System.out.println(billid);
					request.setAttribute("billdata",billDetail);
					RequestDispatcher reqs =request.getRequestDispatcher("success.jsp");
					reqs.forward(request,response);
					
					
				} catch (BillException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Problem occured at calculate.do");
					//response.sendRedirect("invalid.jsp");//you cant pass any msg
					String cnoerror="Consumer no does not exsit";
					request.setAttribute("consumernoerror", cnoerror);
					RequestDispatcher reqs =request.getRequestDispatcher("mainMenu.jsp");
					reqs.forward(request,response);
				}
			
			}
			
		}
		
	}
}
