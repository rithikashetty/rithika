package com.cg.ebill.services;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;


public interface IEbillService {

	User getUserDetails(String userName) throws BillException;
	boolean isUserAuthenticated(String username,String password) throws BillException;
	public int addBillDetail(int consumerno, BillDetails billDetail) throws BillException;
}
